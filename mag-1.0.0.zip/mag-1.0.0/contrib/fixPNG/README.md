Shell script to fix error in debug log:

GUI: libpng warning: iCCP: known incorrect sRGB profile