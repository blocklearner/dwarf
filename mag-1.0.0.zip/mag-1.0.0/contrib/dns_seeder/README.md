# DNS Seeder Test
Will return the number of nodes from each dns seeder in the list.

If 0 is returned then there was an error or its not working properly.

```
python test_seeder.py
```