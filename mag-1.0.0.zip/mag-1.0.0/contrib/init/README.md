Sample configuration files for:

SystemD: dwarfd.service
Upstart: dwarfd.conf
OpenRC:  dwarfd.openrc
         dwarfd.openrcconf
CentOS:  dwarfd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
